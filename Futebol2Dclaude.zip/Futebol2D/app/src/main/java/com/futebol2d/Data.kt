package com.futebol2d

class LeagueDef(val name: String, val country: String, val base: Int, val teams: List<String>)

object Data {
    val posNames = listOf("Zagueiro", "Meia", "Atacante")

    val leagues: List<LeagueDef> = listOf(
        LeagueDef("Brasileirão Série A", "Brasil", 76, listOf(
            "Palmeiras", "Flamengo", "Botafogo", "Fluminense", "Atlético-MG", "São Paulo", "Internacional",
            "Grêmio", "Corinthians", "Cruzeiro", "Bahia", "Fortaleza", "Vasco", "Santos", "Athletico-PR",
            "Red Bull Bragantino", "Vitória", "Juventude", "Cuiabá", "Criciúma")),
        LeagueDef("Brasileirão Série B", "Brasil", 62, listOf(
            "Coritiba", "Goiás", "Sport", "Ceará", "Mirassol", "Vila Nova", "Novorizontino", "Ponte Preta",
            "Guarani", "Operário-PR", "Avaí", "Chapecoense", "Amazonas", "Paysandu", "Remo", "Botafogo-SP",
            "América-MG", "CRB", "Athletic-MG", "Volta Redonda")),
        LeagueDef("Premier League", "Inglaterra", 82, listOf(
            "Manchester City", "Arsenal", "Liverpool", "Chelsea", "Manchester United", "Tottenham", "Newcastle",
            "Aston Villa", "Brighton", "West Ham", "Crystal Palace", "Fulham", "Brentford", "Wolves", "Everton",
            "Bournemouth", "Nottingham Forest", "Leeds United", "Burnley", "Sunderland")),
        LeagueDef("Championship", "Inglaterra", 66, listOf(
            "Leicester City", "Southampton", "Ipswich Town", "Sheffield United", "Middlesbrough", "Norwich City",
            "West Bromwich", "Coventry City", "Watford", "Stoke City", "Swansea City", "Hull City", "Bristol City",
            "Blackburn", "Preston", "Millwall", "Derby County", "Portsmouth", "Oxford United",
            "Queens Park Rangers", "Sheffield Wednesday", "Plymouth", "Cardiff City", "Birmingham City")),
        LeagueDef("La Liga", "Espanha", 80, listOf(
            "Real Madrid", "Barcelona", "Atlético de Madrid", "Athletic Club", "Real Sociedad", "Villarreal",
            "Real Betis", "Sevilla", "Valencia", "Girona", "Osasuna", "Celta de Vigo", "Mallorca",
            "Rayo Vallecano", "Getafe", "Espanyol", "Alavés", "Elche", "Levante", "Real Oviedo")),
        LeagueDef("Serie A", "Itália", 79, listOf(
            "Inter", "Milan", "Juventus", "Napoli", "Atalanta", "Roma", "Lazio", "Fiorentina", "Bologna",
            "Torino", "Udinese", "Genoa", "Cagliari", "Como", "Parma", "Lecce", "Verona", "Sassuolo",
            "Pisa", "Cremonese")),
        LeagueDef("Bundesliga", "Alemanha", 79, listOf(
            "Bayern München", "Borussia Dortmund", "Bayer Leverkusen", "RB Leipzig", "Eintracht Frankfurt",
            "VfB Stuttgart", "Wolfsburg", "Borussia M'gladbach", "Freiburg", "Werder Bremen", "Hoffenheim",
            "Mainz 05", "Augsburg", "Union Berlin", "St. Pauli", "Heidenheim", "FC Köln", "Hamburger SV")),
        LeagueDef("Ligue 1", "França", 76, listOf(
            "Paris Saint-Germain", "Monaco", "Marseille", "Lille", "Lyon", "Nice", "Lens", "Rennes",
            "Strasbourg", "Nantes", "Toulouse", "Brest", "Auxerre", "Angers", "Le Havre", "Lorient",
            "Paris FC", "Metz")),
        LeagueDef("Primeira Liga", "Portugal", 73, listOf(
            "Benfica", "Porto", "Sporting CP", "Braga", "Vitória SC", "Famalicão", "Moreirense", "Gil Vicente",
            "Estoril", "Rio Ave", "Santa Clara", "Arouca", "Casa Pia", "Nacional", "Boavista", "Alverca",
            "Estrela Amadora", "AVS")),
        LeagueDef("Eredivisie", "Holanda", 73, listOf(
            "Ajax", "PSV", "Feyenoord", "AZ Alkmaar", "Twente", "Utrecht", "Heerenveen", "Sparta Rotterdam",
            "NEC Nijmegen", "Go Ahead Eagles", "Fortuna Sittard", "Groningen", "PEC Zwolle", "Heracles",
            "Willem II", "NAC Breda", "Excelsior", "Telstar")),
        LeagueDef("Liga Profesional", "Argentina", 72, listOf(
            "Boca Juniors", "River Plate", "Racing Club", "Independiente", "San Lorenzo", "Estudiantes",
            "Vélez Sarsfield", "Rosario Central", "Talleres", "Lanús", "Defensa y Justicia",
            "Argentinos Juniors", "Huracán", "Newell's Old Boys", "Banfield", "Godoy Cruz", "Tigre",
            "Belgrano", "Instituto", "Platense")),
        LeagueDef("Süper Lig", "Turquia", 70, listOf(
            "Galatasaray", "Fenerbahçe", "Beşiktaş", "Trabzonspor", "Başakşehir", "Samsunspor", "Göztepe",
            "Kasımpaşa", "Konyaspor", "Alanyaspor", "Rizespor", "Antalyaspor", "Gaziantep", "Kayserispor",
            "Eyüpspor", "Kocaelispor", "Gençlerbirliği", "Fatih Karagümrük")),
        LeagueDef("Saudi Pro League", "Arábia Saudita", 70, listOf(
            "Al-Hilal", "Al-Nassr", "Al-Ittihad", "Al-Ahli", "Al-Shabab", "Al-Taawoun", "Al-Fateh",
            "Al-Ettifaq", "Al-Fayha", "Damac", "Al-Khaleej", "Al-Raed", "Al-Okhdood", "Al-Najma",
            "Al-Riyadh", "Al-Kholood", "Neom", "Al-Qadsiah")),
        LeagueDef("MLS", "EUA / Canadá", 68, listOf(
            "Inter Miami", "LAFC", "LA Galaxy", "Seattle Sounders", "Columbus Crew", "FC Cincinnati",
            "Atlanta United", "New York City FC", "Philadelphia Union", "Orlando City", "Portland Timbers",
            "Nashville SC", "Austin FC", "Real Salt Lake", "Vancouver Whitecaps", "Toronto FC",
            "Chicago Fire", "Minnesota United", "Sporting Kansas City", "San Diego FC")),
        LeagueDef("Liga MX", "México", 68, listOf(
            "Club América", "Chivas", "Cruz Azul", "Tigres", "Monterrey", "Pumas", "Toluca", "Santos Laguna",
            "León", "Pachuca", "Atlas", "Necaxa", "Tijuana", "Querétaro", "Puebla", "Mazatlán", "Juárez",
            "San Luis")),
        LeagueDef("Pro League", "Bélgica", 68, listOf(
            "Club Brugge", "Union Saint-Gilloise", "Anderlecht", "Genk", "Gent", "Antwerp", "Standard Liège",
            "Cercle Brugge", "Mechelen", "Westerlo", "Charleroi", "OH Leuven", "Sint-Truiden", "Dender",
            "Zulte Waregem", "Raal La Louvière")),
        LeagueDef("Scottish Premiership", "Escócia", 63, listOf(
            "Celtic", "Rangers", "Hearts", "Aberdeen", "Hibernian", "Dundee United", "Motherwell",
            "Kilmarnock", "St Mirren", "Dundee", "Falkirk", "Livingston")),
        LeagueDef("J1 League", "Japão", 66, listOf(
            "Vissel Kobe", "Kashima Antlers", "Urawa Reds", "Kawasaki Frontale", "Yokohama F. Marinos",
            "Sanfrecce Hiroshima", "Gamba Osaka", "Cerezo Osaka", "FC Tokyo", "Nagoya Grampus", "Kyoto Sanga",
            "Machida Zelvia", "Avispa Fukuoka", "Shimizu S-Pulse", "Tokyo Verdy", "Albirex Niigata",
            "Júbilo Iwata", "Fagiano Okayama", "Kashiwa Reysol", "Shonan Bellmare"))
    )
}
