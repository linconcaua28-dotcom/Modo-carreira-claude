package com.futebol2d

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

class P(val team: Int, val idx: Int, val role: Int, val hx: Float, val hy: Float) {
    var x = hx
    var y = hy
    var vx = 0f
    var vy = 0f
    var face = 0f
    var cool = 0f
    var stun = 0f
    var boost = 0f
    var think = 0f
    var shoot = 60f
    var pass = 60f
    var drib = 60f
    var spd = 60f
    var tackle = 60f
    var human = false
    var tx = hx
    var ty = hy
    var sprint = false
}

/** Partida 11x11. Time 0 (o seu) ataca para a direita (x = W). */
class Match(
    val myName: String,
    val oppName: String,
    myStr: Int,
    oppStr: Int,
    private val career: Career,
    private val halfSecs: Float
) {
    companion object {
        const val W = 1800f
        const val H = 1000f
        const val GH = 125f // meia-largura do gol
    }

    val players = ArrayList<P>()
    lateinit var me: P

    var bx = W / 2
    var by = H / 2
    var bvx = 0f
    var bvy = 0f
    var bspin = 0f
    var owner: P? = null
    var recv: P? = null
    var lastTouch: P? = null
    var prevTouch: P? = null

    var score0 = 0
    var score1 = 0
    var time = 0f
    var half = 1
    var state = 2 // 0 jogando, 1 gol, 2 reinicio, 3 intervalo, 4 fim
    var stateT = 1f
    var msg = ""
    private var lastScorer = 0

    // input
    @Volatile var jx = 0f
    @Volatile var jy = 0f
    @Volatile var sprintHeld = false

    // estado do jogador
    var stam = 100f
    private var stamLock = false
    var superM = 40f
    var callT = 0f
    private var callDelay = 0f
    private var skillCd = 0f
    private var sinceMePass = 99f
    private var meLastKick = false

    // estatisticas
    var myGoals = 0
    var myAssists = 0
    var passOk = 0
    var passBad = 0
    var dribbles = 0
    var losses = 0
    var shots = 0

    private val fx = floatArrayOf(0.04f, 0.20f, 0.20f, 0.20f, 0.20f, 0.45f, 0.45f, 0.45f, 0.45f, 0.70f, 0.70f)
    private val fy = floatArrayOf(0.5f, 0.15f, 0.38f, 0.62f, 0.85f, 0.15f, 0.38f, 0.62f, 0.85f, 0.38f, 0.62f)
    private val roles = intArrayOf(0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3)

    private fun rnd() = Random.nextFloat()

    init {
        for (t in 0..1) {
            val str = (if (t == 0) myStr else oppStr).toFloat()
            for (i in 0..10) {
                val hx = if (t == 0) fx[i] * W else W - fx[i] * W
                val p = P(t, i, roles[i], hx, fy[i] * H)
                p.shoot = str + Random.nextInt(-6, 7)
                p.pass = str + Random.nextInt(-6, 7)
                p.drib = str + Random.nextInt(-6, 7)
                p.spd = str + Random.nextInt(-6, 7)
                p.tackle = str + Random.nextInt(-6, 7)
                if (p.role == 3) p.shoot += 5f
                if (p.role == 1) { p.tackle += 6f; p.shoot -= 5f }
                p.face = if (t == 0) 0f else PI.toFloat()
                players.add(p)
            }
        }
        val slot = when (career.pos) { 0 -> 2; 1 -> 6; else -> 9 }
        me = players[slot]
        me.human = true
        me.shoot = career.shoot.toFloat()
        me.pass = career.pass.toFloat()
        me.drib = career.drib.toFloat()
        me.spd = career.spd.toFloat()
        me.tackle = career.def.toFloat()
        resetKickoff(if (Random.nextBoolean()) 0 else 1)
        msg = "Pontapé inicial"
    }

    // ---------------------------------------------------------------- fluxo

    private fun resetKickoff(team: Int) {
        for (p in players) {
            val px = if (p.team == 0) min(p.hx, W / 2 - 40f) else max(p.hx, W / 2 + 40f)
            p.x = px; p.y = p.hy
            p.vx = 0f; p.vy = 0f
            p.cool = 0f; p.stun = 0f; p.boost = 0f
            p.face = if (p.team == 0) 0f else PI.toFloat()
            p.think = 0.3f
            p.tx = p.x; p.ty = p.y
        }
        val k = players[team * 11 + 9]
        k.x = W / 2 + (if (team == 0) -14f else 14f)
        k.y = H / 2
        bx = W / 2; by = H / 2; bvx = 0f; bvy = 0f; bspin = 0f
        owner = k; lastTouch = k; prevTouch = null; recv = null
        state = 2; stateT = 1.0f; msg = "Pontapé inicial"
        carryBall(k, 0f)
    }

    private fun afterFreeze() {
        when (state) {
            1 -> resetKickoff(1 - lastScorer)
            3 -> { half = 2; resetKickoff(1) }
            2 -> state = 0
        }
    }

    fun update(dt0: Float) {
        val dt = min(dt0, 0.033f)
        if (state == 4) return
        if (state != 0) {
            stateT -= dt
            val ow = owner
            if (state == 2 && ow != null) carryBall(ow, 0f)
            if (stateT <= 0f) afterFreeze()
            return
        }

        time += dt * 45f / halfSecs
        if (half == 1 && time >= 45f) { time = 45f; state = 3; stateT = 3f; msg = "Intervalo"; return }
        if (time >= 90f) { time = 90f; state = 4; msg = "Fim de jogo"; return }

        sinceMePass += dt
        if (callT > 0f) callT -= dt
        if (skillCd > 0f) skillCd -= dt
        superM = min(100f, superM + 2.5f * dt)

        // pedir passe: o companheiro com a bola reage e toca para voce
        val o0 = owner
        if (callT > 0f && o0 != null && o0.team == 0 && o0 !== me) {
            callDelay -= dt
            if (callDelay <= 0f) { kickPass(o0, me); callT = 0f }
        }

        for (p in players) {
            p.cool = max(0f, p.cool - dt)
            p.stun = max(0f, p.stun - dt)
            p.boost = max(0f, p.boost - dt)
            var desX: Float
            var desY: Float
            var sprinting: Boolean
            if (p.human) {
                var jxx = jx
                var jyy = jy
                val m = hypot(jxx, jyy)
                if (m > 1f) { jxx /= m; jyy /= m }
                desX = jxx; desY = jyy
                sprinting = false
                if (sprintHeld && m > 0.2f && stam > 0f && !stamLock) {
                    sprinting = true
                    stam -= 24f * dt
                    if (stam <= 0f) { stam = 0f; stamLock = true }
                } else {
                    stam = min(100f, stam + 10f * dt)
                    if (stamLock && stam > 30f) stamLock = false
                }
                p.sprint = sprinting
            } else {
                ai(p, dt)
                val ddx = p.tx - p.x
                val ddy = p.ty - p.y
                val dd = hypot(ddx, ddy)
                if (dd > 6f) {
                    val f = min(1f, dd / 70f)
                    desX = ddx / dd * f; desY = ddy / dd * f
                } else { desX = 0f; desY = 0f }
                sprinting = p.sprint
            }
            var maxV = 140f + p.spd * 1.6f
            if (sprinting) maxV *= 1.25f
            if (owner === p) maxV *= 0.93f
            if (p.boost > 0f) maxV *= 1.35f
            if (p.stun > 0f) maxV *= 0.4f
            val acc = if (owner === p) 6f else 8.5f
            val k = min(1f, acc * dt)
            p.vx += (desX * maxV - p.vx) * k
            p.vy += (desY * maxV - p.vy) * k
            p.x += p.vx * dt
            p.y += p.vy * dt
            val sp = hypot(p.vx, p.vy)
            if (sp > 25f) {
                val target = atan2(p.vy, p.vx)
                var d = target - p.face
                val twoPi = (2.0 * PI).toFloat()
                while (d > PI) d -= twoPi
                while (d < -PI) d += twoPi
                val maxTurn = 12f * dt
                p.face += d.coerceIn(-maxTurn, maxTurn)
            }
        }

        // separacao entre jogadores
        for (i in 0 until players.size) for (j in i + 1 until players.size) {
            val a = players[i]; val b = players[j]
            val dx = b.x - a.x; val dy = b.y - a.y
            val d2 = dx * dx + dy * dy
            if (d2 < 26f * 26f && d2 > 0.01f) {
                val d = sqrt(d2)
                val push = (26f - d) * 0.5f
                val nx = dx / d; val ny = dy / d
                a.x -= nx * push; a.y -= ny * push
                b.x += nx * push; b.y += ny * push
            }
        }
        for (p in players) {
            p.x = p.x.coerceIn(10f, W - 10f)
            p.y = p.y.coerceIn(10f, H - 10f)
        }

        // bola
        val ow = owner
        if (ow != null) {
            carryBall(ow, dt)
            for (q in players) {
                if (q.team == ow.team || q.role == 0 || q.human || q.cool > 0f || q.stun > 0.2f) continue
                val d = hypot(q.x - bx, q.y - by)
                if (d < 24f) {
                    var rate = 1.8f * q.tackle / (q.tackle + ow.drib)
                    if (ow.sprint) rate *= 1.4f
                    if (rnd() < rate * dt) { steal(q, ow); break }
                }
            }
        } else {
            looseBall(dt)
        }
    }

    private fun carryBall(p: P, dt: Float) {
        val dist = if (p.sprint) 31f else 20f
        val tx = (p.x + cos(p.face) * dist).coerceIn(2f, W - 2f)
        val ty = (p.y + sin(p.face) * dist).coerceIn(2f, H - 2f)
        if (dt <= 0f) {
            bx = tx; by = ty; bvx = 0f; bvy = 0f
            return
        }
        bvx = (tx - bx) * 13f
        bvy = (ty - by) * 13f
        bx += bvx * dt
        by += bvy * dt
    }

    private fun looseBall(dt: Float) {
        bx += bvx * dt
        by += bvy * dt
        val fr = exp(-1.0f * dt)
        bvx *= fr; bvy *= fr
        if (bspin != 0f) {
            val s0 = hypot(bvx, bvy)
            if (s0 > 100f) {
                val a = bspin * dt
                val c = cos(a); val s = sin(a)
                val nx = bvx * c - bvy * s
                val ny = bvx * s + bvy * c
                bvx = nx; bvy = ny
            }
            bspin *= exp(-1.2f * dt)
        }
        checkBounds()
        if (state != 0) return

        val sp = hypot(bvx, bvy)
        var best: P? = null
        var bd = 1e9f
        for (p in players) {
            if (p.cool > 0f || p.stun > 0.35f) continue
            val d = hypot(p.x - bx, p.y - by)
            if (p.role == 0) {
                if (d < 34f) {
                    val towardsOwnGoal = (p.team == 0 && bvx < 0f) || (p.team == 1 && bvx > 0f)
                    if (sp >= 420f && towardsOwnGoal) {
                        p.cool = 0.5f
                        var ps = 0.93f - sp / 2100f + (p.tackle - 60f) / 220f
                        if (abs(by - H / 2) > GH * 0.62f) ps -= 0.22f
                        ps = ps.coerceIn(0.1f, 0.9f)
                        if (rnd() < ps) {
                            if (sp < 700f) {
                                takeBall(p)
                                return
                            } else {
                                bvx = -bvx * 0.35f + (rnd() - 0.5f) * 220f
                                bvy = bvy * 0.5f + (rnd() - 0.5f) * 320f
                                p.cool = 0.4f
                                if (lastTouch !== p) { prevTouch = lastTouch; lastTouch = p }
                            }
                        }
                    } else if (sp < 800f && d < bd) { best = p; bd = d }
                }
            } else {
                val reach = if (p === recv) 27f else 21f
                val lim = if (p === recv) 880f else 400f + p.drib * 2.2f
                if (d < reach && sp < lim && d < bd) { best = p; bd = d }
            }
        }
        val b = best
        if (b != null) takeBall(b)
    }

    private fun takeBall(p: P) {
        if (meLastKick) {
            if (p.team == 0 && p !== me) { passOk++; superM = min(100f, superM + 4f) }
            else if (p.team == 1) passBad++
            meLastKick = false
        }
        owner = p; recv = null
        bvx = 0f; bvy = 0f; bspin = 0f
        if (lastTouch !== p) { prevTouch = lastTouch; lastTouch = p }
        p.think = if (p.role == 0) 0.9f else 0.25f + rnd() * 0.25f
    }

    private fun steal(q: P, old: P) {
        if (old === me) losses++
        old.cool = 0.5f
        owner = q; recv = null
        if (lastTouch !== q) { prevTouch = lastTouch; lastTouch = q }
        q.think = 0.3f
        if (q === me) superM = min(100f, superM + 8f)
    }

    private fun checkBounds() {
        if (bx < 0f || bx > W) {
            val inGoal = abs(by - H / 2) < GH
            if (inGoal) { goal(if (bx < 0f) 1 else 0); return }
            val defTeam = if (bx < 0f) 0 else 1
            val lt = lastTouch?.team ?: defTeam
            if (lt == defTeam) {
                restart(1 - defTeam, if (bx < 0f) 6f else W - 6f, if (by < H / 2) 6f else H - 6f, "Escanteio", false)
            } else {
                restart(defTeam, if (bx < 0f) 70f else W - 70f, H / 2, "Tiro de meta", true)
            }
        } else if (by < 0f || by > H) {
            val lt = lastTouch?.team ?: 0
            restart(1 - lt, bx.coerceIn(30f, W - 30f), if (by < 0f) 6f else H - 6f, "Lateral", false)
        }
    }

    private fun restart(team: Int, x: Float, y: Float, text: String, gk: Boolean) {
        var best: P? = null
        var bd = 1e9f
        for (p in players) {
            if (p.team != team) continue
            if ((p.role == 0) != gk) continue
            val d = hypot(p.x - x, p.y - y)
            if (d < bd) { bd = d; best = p }
        }
        val p = best ?: return
        p.x = x; p.y = y; p.vx = 0f; p.vy = 0f
        val gx = if (team == 0) W else 0f
        p.face = atan2(H / 2 - y, gx - x)
        takeBall(p)
        p.think = 0.6f
        carryBall(p, 0f)
        state = 2; stateT = 0.9f; msg = text
    }

    private fun goal(t: Int) {
        if (t == 0) score0++ else score1++
        lastScorer = t
        val s = lastTouch
        if (t == 0 && s != null) {
            if (s === me) myGoals++
            else if (prevTouch === me && sinceMePass < 9f) myAssists++
        }
        state = 1; stateT = 2.8f; msg = "GOOOL!"
        owner = null
        bvx = 0f; bvy = 0f
    }

    // ------------------------------------------------------------ acoes

    fun act(code: Int) {
        if (state != 0) return
        val hasBall = owner === me
        when (code) {
            1 -> if (hasBall) humanPass() else tackleTry()
            2 -> if (hasBall) shoot(me, 0)
            3 -> if (hasBall) shoot(me, 1)
            4 -> if (hasBall && superM >= 100f) { superM = 0f; shoot(me, 2) }
            5 -> { callT = 2.5f; callDelay = 0.25f + rnd() * 0.35f }
            6 -> if (hasBall) skillMove()
        }
    }

    private fun laneBlocked(a: P, b: P): Boolean {
        val dx = b.x - a.x
        val dy = b.y - a.y
        val l2 = dx * dx + dy * dy
        if (l2 < 1f) return false
        for (o in players) {
            if (o.team == a.team) continue
            val t = ((o.x - a.x) * dx + (o.y - a.y) * dy) / l2
            if (t < 0.1f || t > 0.95f) continue
            val px = a.x + dx * t
            val py = a.y + dy * t
            if (hypot(o.x - px, o.y - py) < 30f) return true
        }
        return false
    }

    private fun humanPass() {
        val m = hypot(jx, jy)
        val hasDir = m > 0.3f
        val ax = if (hasDir) jx / m else cos(me.face)
        val ay = if (hasDir) jy / m else sin(me.face)
        var best: P? = null
        var bs = -99f
        for (q in players) {
            if (q.team != 0 || q === me) continue
            val dx = q.x - me.x
            val dy = q.y - me.y
            val d = hypot(dx, dy)
            if (d < 40f) continue
            val ca = (dx * ax + dy * ay) / d
            if (ca < 0.4f) continue
            var s = ca * 1.5f - d / 2200f
            if (laneBlocked(me, q)) s -= 0.5f
            if (s > bs) { bs = s; best = q }
        }
        if (best == null) {
            var bd = 1e9f
            for (q in players) {
                if (q.team == 0 && q !== me) {
                    val d = hypot(q.x - me.x, q.y - me.y)
                    if (d < bd) { bd = d; best = q }
                }
            }
        }
        val b = best
        if (b != null) kickPass(me, b)
    }

    private fun kickPass(from: P, to: P) {
        val lead = 0.3f
        val dx = to.x + to.vx * lead - bx
        val dy = to.y + to.vy * lead - by
        val d = max(1f, hypot(dx, dy))
        val err = (1f - from.pass / 100f) * 0.25f * (rnd() * 2f - 1f)
        val a = atan2(dy, dx) + err
        val sp = (d * 1.45f + 120f).coerceIn(300f, 900f)
        bvx = cos(a) * sp
        bvy = sin(a) * sp
        bspin = 0f
        owner = null
        recv = to
        from.cool = 0.35f
        from.think = 0.5f
        if (lastTouch !== from) { prevTouch = lastTouch; lastTouch = from }
        if (from === me) { sinceMePass = 0f; meLastKick = true }
    }

    /** kind: 0 normal, 1 colocado, 2 super chute */
    private fun shoot(p: P, kind: Int) {
        val gx = if (p.team == 0) W else 0f
        val oppGk = players[(1 - p.team) * 11]
        val ty: Float
        if (p.human) {
            val st = if (abs(jy) > 0.35f) (if (jy > 0f) 1f else -1f) else 0f
            ty = if (st != 0f) H / 2 + st * (GH - 32f) * (if (kind == 1) 1f else 0.75f)
            else if (kind == 1) (if (oppGk.y > H / 2) H / 2 - (GH - 32f) else H / 2 + (GH - 32f))
            else H / 2 + (rnd() - 0.5f) * GH * 1.2f
        } else {
            ty = H / 2 + (rnd() * 2f - 1f) * (GH - 35f)
        }
        val dx = gx - p.x
        val dy = ty - p.y
        val dist = hypot(dx, dy)
        var err = (1f - p.shoot / 100f) * 0.16f + dist / 20000f
        var spd = when (kind) { 1 -> 740f; 2 -> 1300f; else -> 900f }
        err *= when (kind) { 1 -> 0.35f; 2 -> 1.6f; else -> 1f }
        if (!p.human) spd = 800f + rnd() * 250f
        var a = atan2(dy, dx) + (rnd() * 2f - 1f) * err
        var spin = 0f
        if (kind == 1 && p.human) {
            spin = if (Random.nextBoolean()) 0.8f else -0.8f
            a -= spin * (dist / spd) * 0.45f
        }
        bvx = cos(a) * spd
        bvy = sin(a) * spd
        bspin = spin
        owner = null
        recv = null
        p.cool = 0.4f
        if (lastTouch !== p) { prevTouch = lastTouch; lastTouch = p }
        if (p === me) { meLastKick = false; shots++ }
    }

    private fun skillMove() {
        if (skillCd > 0f) return
        skillCd = 1.1f
        val m = hypot(jx, jy)
        val ax = cos(me.face)
        val ay = sin(me.face)
        val side = if (m > 0.3f) {
            if (ax * jy - ay * jx > 0f) 1f else -1f
        } else {
            if (Random.nextBoolean()) 1f else -1f
        }
        me.vx += -ay * side * 360f
        me.vy += ax * side * 360f
        me.boost = 0.5f
        var beaten = 0
        for (q in players) {
            if (q.team != 1 || q.role == 0) continue
            val dx = q.x - me.x
            val dy = q.y - me.y
            val d = hypot(dx, dy)
            if (d < 110f && (dx * ax + dy * ay) > -20f) {
                val pr = (0.38f + (me.drib - q.tackle) / 150f).coerceIn(0.12f, 0.88f)
                if (rnd() < pr) { q.stun = 0.8f; beaten++ }
            }
        }
        dribbles += beaten
        superM = min(100f, superM + 10f * beaten)
    }

    private fun tackleTry() {
        if (me.cool > 0f) return
        val o = owner ?: return
        if (o.team == 0) return
        val d = hypot(o.x - me.x, o.y - me.y)
        me.cool = 0.6f
        if (d > 46f) { me.stun = 0.4f; return }
        val pr = (0.5f + (me.tackle - o.drib) / 160f).coerceIn(0.2f, 0.85f)
        if (rnd() < pr) {
            steal(me, o)
        } else {
            me.stun = 0.5f
            if (rnd() < 0.2f) {
                restart(1, bx.coerceIn(30f, W - 30f), by.coerceIn(30f, H - 30f), "Falta!", false)
            }
        }
    }

    // ------------------------------------------------------------------ IA

    private fun isClosest(p: P, x: Float, y: Float, n: Int): Boolean {
        val dp = hypot(p.x - x, p.y - y)
        var cnt = 0
        for (q in players) {
            if (q.team != p.team || q === p || q.role == 0 || q.human) continue
            if (hypot(q.x - x, q.y - y) < dp) cnt++
        }
        return cnt < n
    }

    private fun ai(p: P, dt: Float) {
        p.sprint = false
        if (p.role == 0) { gkAi(p); return }
        val dir = if (p.team == 0) 1f else -1f
        val own = owner
        val teamHas = own != null && own.team == p.team
        val oppHas = own != null && own.team != p.team
        val oppGoalX = if (p.team == 0) W else 0f
        if (own === p) { ownerAi(p, dt, dir, oppGoalX); return }
        if (own == null) {
            if (p === recv) {
                p.tx = bx + bvx * 0.2f; p.ty = by + bvy * 0.2f; p.sprint = true
                return
            }
            if (isClosest(p, bx, by, 1)) {
                p.tx = bx + bvx * 0.25f; p.ty = by + bvy * 0.25f; p.sprint = true
                return
            }
        } else if (oppHas) {
            if (isClosest(p, own.x, own.y, 2)) {
                p.tx = own.x + own.vx * 0.25f
                p.ty = own.y + own.vy * 0.25f
                p.sprint = hypot(own.x - p.x, own.y - p.y) > 70f
                return
            }
        }
        var tx = p.hx + (bx - W / 2f) * 0.5f
        val ty = p.hy + (by - H / 2f) * 0.35f
        if (teamHas) tx += dir * (if (p.role == 3) 170f else if (p.role == 2) 90f else 20f)
        else if (oppHas) tx -= dir * (if (p.role == 3) 60f else 40f)
        p.tx = tx.coerceIn(40f, W - 40f)
        p.ty = ty.coerceIn(40f, H - 40f)
    }

    private fun gkAi(p: P) {
        val gx = p.hx
        var ty = H / 2 + (by - H / 2) * 0.22f
        var tx = gx
        val towards = if (p.team == 0) bvx < -120f else bvx > 120f
        if (owner == null && towards) {
            val t = (gx - bx) / bvx
            if (t > 0f && t < 1.5f) ty = by + bvy * t
        }
        ty = ty.coerceIn(H / 2 - GH - 10f, H / 2 + GH + 10f)
        if (owner == null && abs(bx - gx) < 240f && hypot(bvx, bvy) < 260f && abs(by - H / 2) < 330f) {
            tx = bx; ty = by
        }
        p.tx = tx; p.ty = ty
        p.sprint = true
    }

    private fun ownerAi(p: P, dt: Float, dir: Float, gx: Float) {
        p.think -= dt
        var near = 1e9f
        var no: P? = null
        for (o in players) {
            if (o.team != p.team) {
                val d = hypot(o.x - p.x, o.y - p.y)
                if (d < near) { near = d; no = o }
            }
        }
        if (p.think <= 0f) {
            p.think = 0.35f + rnd() * 0.45f
            val dGoal = abs(gx - p.x)
            val central = abs(p.y - H / 2) < 340f
            if (p.role != 0 && dGoal < 480f && central && rnd() < 0.5f) {
                shoot(p, 0)
                return
            }
            if (p.role == 0 || near < 85f || rnd() < 0.2f) {
                val t = bestPass(p, dir)
                if (t != null) { kickPass(p, t); return }
            }
        }
        if (p.role == 0) { p.tx = p.x; p.ty = p.y; return }
        var ty = p.y + (H / 2f - p.y) * 0.25f
        val n = no
        if (n != null && near < 130f) ty += (if (p.y >= n.y) 1f else -1f) * 180f
        p.tx = (p.x + dir * 300f).coerceIn(30f, W - 30f)
        p.ty = ty.coerceIn(40f, H - 40f)
        p.sprint = near > 140f
    }

    private fun bestPass(from: P, dir: Float): P? {
        var best: P? = null
        var bs = -99f
        for (q in players) {
            if (q.team != from.team || q === from) continue
            val dx = q.x - from.x
            val dy = q.y - from.y
            val d = hypot(dx, dy)
            if (d < 70f || d > 950f) continue
            var s = (dx * dir) / 650f - d / 1500f + rnd() * 0.25f
            s += if (laneBlocked(from, q)) -0.7f else 0.25f
            var near = 1e9f
            for (o in players) if (o.team != from.team) near = min(near, hypot(o.x - q.x, o.y - q.y))
            if (near > 90f) s += 0.3f
            if (q.role == 0 && from.role != 0) s -= 1.0f
            if (q === me && callT > 0f) s += 1.5f
            if (s > bs) { bs = s; best = q }
        }
        if (best == null) {
            var bd = 1e9f
            for (q in players) {
                if (q.team == from.team && q !== from) {
                    val d = hypot(q.x - from.x, q.y - from.y)
                    if (d < bd) { bd = d; best = q }
                }
            }
        }
        return best
    }
}
