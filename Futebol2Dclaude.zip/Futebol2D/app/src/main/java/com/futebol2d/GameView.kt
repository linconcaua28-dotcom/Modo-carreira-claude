package com.futebol2d

import android.annotation.SuppressLint
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

private val WHITE = 0xFFFFFFFF.toInt()
private val BLACK = 0xFF000000.toInt()
private val YELLOW = 0xFFFFD54F.toInt()
private val GRAY = 0xFFB0BEC5.toInt()
private val BG = 0xFF0D1B2A.toInt()
private val GREEN = 0xFF2E7D32.toInt()
private val BLUE = 0xFF1565C0.toInt()
private val RED = 0xFFC62828.toInt()
private val SLATE = 0xFF455A64.toInt()

@SuppressLint("ViewConstructor", "ClickableViewAccessibility")
class GameView(private val act: MainActivity) : SurfaceView(act), SurfaceHolder.Callback, Runnable {

    companion object {
        const val S_MENU = 0
        const val S_POS = 1
        const val S_LEAGUE = 2
        const val S_TEAM = 3
        const val S_HUB = 4
        const val S_MATCH = 5
        const val S_RESULT = 6
        const val S_TABLE = 7
        const val S_TRAIN = 8
        const val S_SEASON = 9
    }

    class Btn(val l: Float, val t: Float, val r: Float, val b: Float, val fn: () -> Unit)

    @Volatile private var running = false
    private var thread: Thread? = null
    private var w = 1920f
    private var h = 1080f
    private var u = 1f

    @Volatile private var screen = S_MENU
    private var career: Career? = Career.load(act)
    private var match: Match? = null
    private var halfSecs = 150f
    private var paused = false

    private var chosenPos = 2
    private var chosenName = "Jogador"
    private var chosenLeague = 0
    private var curHome = true
    private var curOpp = 0
    private var lastRes: Career.MatchRes? = null

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }

    private val ui = ArrayList<Btn>()
    @Volatile private var tapX = -1f
    @Volatile private var tapY = -1f
    @Volatile private var scrollAcc = 0f
    private var downY = 0f
    private var lastY = 0f
    private var moved = false

    // lista
    private var listTitle = ""
    private var listItems: List<String> = emptyList()
    private var listSub: List<String> = emptyList()
    private var listScroll = 0f
    private var listHi = -1
    private var listOnPick: (Int) -> Unit = {}
    private var listBack: () -> Unit = {}

    // controles de partida
    private val actions = ConcurrentLinkedQueue<Int>()
    private var joyId = -1
    private var joyCx = 0f
    private var joyCy = 0f
    private var camX = Match.W / 2
    private var camY = Match.H / 2
    private val ctlOff = arrayOf(
        floatArrayOf(170f, 180f, 100f), floatArrayOf(400f, 130f, 80f), floatArrayOf(350f, 330f, 70f),
        floatArrayOf(150f, 400f, 70f), floatArrayOf(570f, 110f, 62f), floatArrayOf(560f, 290f, 65f),
        floatArrayOf(760f, 200f, 60f)
    )
    private val ctlName = arrayOf("PASSE", "CHUTE", "COLOC.", "SUPER", "PEDIR", "DRIBLE", "CORRER")
    private val ctlCol = intArrayOf(0xFF2E7D32.toInt(), 0xFFEF6C00.toInt(), 0xFF6A1B9A.toInt(),
        0xFFC62828.toInt(), 0xFF00838F.toInt(), 0xFF1565C0.toInt(), 0xFF546E7A.toInt())

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    fun saveNow() { career?.save(act) }

    // ------------------------------------------------------------ ciclo

    override fun surfaceCreated(holder: SurfaceHolder) {
        running = true
        thread = Thread(this).also { it.start() }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        w = width.toFloat(); h = height.toFloat(); u = h / 1080f
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        running = false
        try { thread?.join() } catch (e: InterruptedException) { }
        career?.save(act)
    }

    override fun run() {
        var last = System.nanoTime()
        while (running) {
            val now = System.nanoTime()
            val dt = min(0.05f, (now - last) / 1e9f)
            last = now
            var c: Canvas? = null
            try {
                c = if (Build.VERSION.SDK_INT >= 26) holder.lockHardwareCanvas() else holder.lockCanvas()
            } catch (e: Exception) { }
            if (c == null) { try { Thread.sleep(16) } catch (e: Exception) { }; continue }
            try {
                update(dt)
                draw(c)
            } catch (e: Exception) {
            } finally {
                try { holder.unlockCanvasAndPost(c) } catch (e: Exception) { }
            }
            try { Thread.sleep(4) } catch (e: Exception) { }
        }
    }

    private fun update(dt: Float) {
        val tx = tapX
        if (tx >= 0f) {
            val ty = tapY
            tapX = -1f
            handleTap(tx, ty)
        }
        if (isListScreen()) {
            listScroll += scrollAcc
            scrollAcc = 0f
        } else scrollAcc = 0f
        val m = match
        if (screen == S_MATCH && m != null && !paused) {
            while (true) {
                val a = actions.poll() ?: break
                m.act(a)
            }
            m.update(dt)
        }
    }

    private fun isListScreen() = screen == S_LEAGUE || screen == S_TEAM || screen == S_TABLE || screen == S_SEASON

    private fun handleTap(x: Float, y: Float) {
        for (i in ui.indices.reversed()) {
            val b = ui[i]
            if (x >= b.l && x <= b.r && y >= b.t && y <= b.b) { b.fn(); return }
        }
        if (isListScreen() && y > 170f * u) {
            val idx = ((y - 170f * u + listScroll) / (120f * u)).toInt()
            if (idx in listItems.indices) listOnPick(idx)
        }
    }

    // ---------------------------------------------------------- toque

    private fun matchControls(): Boolean = screen == S_MATCH && !paused && (match?.state ?: 4) != 4

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (matchControls()) { matchTouch(e); return true }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downY = e.y; lastY = e.y; moved = false }
            MotionEvent.ACTION_MOVE -> {
                val dy = e.y - lastY
                lastY = e.y
                if (abs(e.y - downY) > 25f * u) moved = true
                if (moved) scrollAcc -= dy
            }
            MotionEvent.ACTION_UP -> { if (!moved) { tapY = e.y; tapX = e.x } }
        }
        return true
    }

    private fun cx(i: Int) = w - ctlOff[i][0] * u
    private fun cy(i: Int) = h - ctlOff[i][1] * u
    private fun cr(i: Int) = ctlOff[i][2] * u
    private fun hit(i: Int, x: Float, y: Float) = hypot(x - cx(i), y - cy(i)) <= cr(i) * 1.2f

    private fun matchTouch(e: MotionEvent) {
        val m = match ?: return
        val a = e.actionMasked
        val ai = e.actionIndex
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) {
            val id = e.getPointerId(ai)
            val x = e.getX(ai)
            val y = e.getY(ai)
            if (hypot(x - (w - 80f * u), y - 80f * u) < 70f * u) { paused = true; return }
            var used = false
            for (i in 0..5) {
                if (hit(i, x, y)) { actions.add(i + 1); used = true; break }
            }
            if (!used && joyId == -1 && x < w * 0.45f && y > h * 0.2f) {
                joyId = id; joyCx = x; joyCy = y; m.jx = 0f; m.jy = 0f
            }
        }
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            joyId = -1; m.jx = 0f; m.jy = 0f; m.sprintHeld = false
            return
        }
        if (a == MotionEvent.ACTION_POINTER_UP && e.getPointerId(ai) == joyId) {
            joyId = -1; m.jx = 0f; m.jy = 0f
        }
        var sprintNow = false
        for (i in 0 until e.pointerCount) {
            if (a == MotionEvent.ACTION_POINTER_UP && i == ai) continue
            val id = e.getPointerId(i)
            val x = e.getX(i)
            val y = e.getY(i)
            if (id == joyId) {
                val dx = x - joyCx
                val dy = y - joyCy
                val r = hypot(dx, dy)
                val maxR = 130f * u
                val k = if (r > maxR) maxR / r else 1f
                var nx = dx * k / maxR
                var ny = dy * k / maxR
                if (r > maxR) { joyCx += dx * (1 - k); joyCy += dy * (1 - k) }
                if (hypot(nx, ny) < 0.12f) { nx = 0f; ny = 0f }
                m.jx = nx; m.jy = ny
            } else if (hit(6, x, y)) sprintNow = true
        }
        m.sprintHeld = sprintNow
    }

    // ------------------------------------------------------ helpers de UI

    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, al: Paint.Align = Paint.Align.LEFT) {
        tp.textSize = size; tp.color = color; tp.textAlign = al
        c.drawText(s, x, y + size * 0.35f, tp)
    }

    private fun btn(c: Canvas, label: String, l: Float, t: Float, r: Float, b: Float, col: Int, fn: () -> Unit) {
        ui.add(Btn(l, t, r, b, fn))
        fill.color = col
        c.drawRoundRect(l, t, r, b, 24f * u, 24f * u, fill)
        txt(c, label, (l + r) / 2, (t + b) / 2, 42f * u, WHITE, Paint.Align.CENTER)
    }

    private fun openList(title: String, items: List<String>, subs: List<String>, hi: Int, pick: (Int) -> Unit, back: () -> Unit) {
        listTitle = title; listItems = items; listSub = subs; listHi = hi
        listOnPick = pick; listBack = back
        listScroll = 0f; scrollAcc = 0f
    }

    private fun save() { career?.save(act) }

    // ------------------------------------------------------ fluxo do jogo

    private fun openLeagueList() {
        openList("ESCOLHA A LIGA", Data.leagues.map { it.name }, Data.leagues.map { it.country }, -1,
            { i -> pickLeague(i) }, { screen = S_MENU })
        screen = S_LEAGUE
    }

    private fun pickLeague(i: Int) {
        chosenLeague = i
        val lg = Data.leagues[i]
        val subs = lg.teams.indices.map { "força " + (lg.base - it * 14 / lg.teams.size) }
        openList("ESCOLHA O CLUBE - " + lg.name, lg.teams, subs, -1,
            { t -> startNew(t) }, { openLeagueList() })
        screen = S_TEAM
    }

    private fun startNew(t: Int) {
        val c = Career()
        c.start(chosenName, chosenPos, chosenLeague, t)
        career = c
        save()
        screen = S_HUB
    }

    private fun startMatch() {
        val c = career ?: return
        val f = c.myFixture() ?: return
        curHome = f[0] == c.teamIdx
        curOpp = if (curHome) f[1] else f[0]
        match = Match(c.myTeam(), c.teamName(curOpp), c.myStrength(), c.strength(c.leagueIdx, curOpp), c, halfSecs)
        paused = false
        camX = Match.W / 2; camY = Match.H / 2
        joyId = -1
        actions.clear()
        screen = S_MATCH
    }

    private fun finishMatch() {
        val m = match ?: return
        val c = career ?: return
        val rating = Career.calcRating(m.myGoals, m.myAssists, m.passOk, m.passBad, m.dribbles, m.losses, m.score0, m.score1)
        val gain = c.applyPlayerStats(m.myGoals, m.myAssists, rating)
        c.finishRound(m.score0, m.score1)
        lastRes = Career.MatchRes(m.score0, m.score1, m.myGoals, m.myAssists, rating, gain, c.teamName(curOpp), curHome)
        match = null
        save()
        screen = S_RESULT
    }

    private fun simulateRound() {
        val c = career ?: return
        val f = c.myFixture() ?: return
        val home = f[0] == c.teamIdx
        val opp = if (home) f[1] else f[0]
        val s = Career.simScore(c.strength(c.leagueIdx, f[0]), c.strength(c.leagueIdx, f[1]))
        val gf = if (home) s[0] else s[1]
        val ga = if (home) s[1] else s[0]
        val pg = (when (c.pos) { 2 -> 0.32f; 1 -> 0.12f; else -> 0.04f }) * (c.ovr() / 70f)
        var g = 0
        var a = 0
        for (i in 0 until gf) {
            if (Random.nextFloat() < pg) g++ else if (Random.nextFloat() < 0.15f) a++
        }
        val rating = Career.calcRating(g, a, Random.nextInt(8, 25), Random.nextInt(2, 8),
            Random.nextInt(0, 4), Random.nextInt(0, 5), gf, ga)
        val gain = c.applyPlayerStats(g, a, rating)
        c.finishRound(gf, ga)
        lastRes = Career.MatchRes(gf, ga, g, a, rating, gain, c.teamName(opp), home)
        save()
        screen = S_RESULT
    }

    private fun openTable() {
        val c = career ?: return
        val order = c.sorted()
        val items = order.mapIndexed { i, t -> "${i + 1}. ${c.teamName(t)}" }
        val subs = order.map {
            val r = c.table[it]
            "J${r[1]}  V${r[2]}  E${r[3]}  D${r[4]}  SG${r[5] - r[6]}  ${r[0]} pts"
        }
        openList("TABELA - " + c.league().name, items, subs, order.indexOf(c.teamIdx),
            { }, { screen = S_HUB })
        screen = S_TABLE
    }

    private fun openSeasonEnd() {
        val c = career ?: return
        val pos = c.sorted().indexOf(c.teamIdx) + 1
        c.generateOffers()
        val items = ArrayList<String>()
        val subs = ArrayList<String>()
        items.add("Continuar no " + c.myTeam())
        subs.add("")
        for (o in c.offers) {
            items.add(Data.leagues[o[0]].teams[o[1]])
            subs.add(Data.leagues[o[0]].name + "  (força " + c.strength(o[0], o[1]) + ")")
        }
        openList("Temporada ${c.season} encerrada: ${pos}º lugar - propostas", items, subs, 0,
            { i ->
                c.newSeason(i - 1)
                save()
                screen = S_HUB
            }, { screen = S_HUB })
        screen = S_SEASON
    }

    // ------------------------------------------------------------ desenho

    private fun draw(c: Canvas) {
        ui.clear()
        when (screen) {
            S_MENU -> drawMenu(c)
            S_POS -> drawPos(c)
            S_LEAGUE, S_TEAM, S_TABLE, S_SEASON -> drawList(c)
            S_HUB -> drawHub(c)
            S_RESULT -> drawResult(c)
            S_TRAIN -> drawTrain(c)
            S_MATCH -> drawMatchScreen(c)
        }
    }

    private fun drawMenu(c: Canvas) {
        c.drawColor(BG)
        txt(c, "FUTEBOL 2D", w / 2, 220f * u, 130f * u, YELLOW, Paint.Align.CENTER)
        txt(c, "MODO CARREIRA", w / 2, 330f * u, 60f * u, WHITE, Paint.Align.CENTER)
        val bl = w / 2 - 320f * u
        val br = w / 2 + 320f * u
        btn(c, "NOVA CARREIRA", bl, 420f * u, br, 540f * u, GREEN) { screen = S_POS }
        if (career != null) btn(c, "CONTINUAR CARREIRA", bl, 570f * u, br, 690f * u, BLUE) { screen = S_HUB }
        val label = "TEMPO DE JOGO: " + (halfSecs / 60f).let { String.format("%.1f", it) } + " min por tempo"
        btn(c, label, bl, 720f * u, br, 840f * u, SLATE) {
            halfSecs = if (halfSecs < 100f) 150f else if (halfSecs < 200f) 240f else 90f
        }
    }

    private fun drawPos(c: Canvas) {
        c.drawColor(BG)
        txt(c, "ESCOLHA SUA POSIÇÃO", w / 2, 140f * u, 70f * u, WHITE, Paint.Align.CENTER)
        val names = listOf("ZAGUEIRO", "MEIA", "ATACANTE")
        for (i in 0..2) {
            val l = w / 2 - 320f * u
            val t = (260f + i * 170f) * u
            btn(c, names[i], l, t, w / 2 + 320f * u, t + 130f * u, GREEN) {
                chosenPos = i
                act.askName("Jogador") { nm -> chosenName = nm; openLeagueList() }
            }
        }
        btn(c, "VOLTAR", 30f * u, 30f * u, 300f * u, 120f * u, SLATE) { screen = S_MENU }
    }

    private fun drawList(c: Canvas) {
        c.drawColor(BG)
        txt(c, listTitle, w / 2, 90f * u, 52f * u, WHITE, Paint.Align.CENTER)
        btn(c, "VOLTAR", 30f * u, 30f * u, 300f * u, 120f * u, SLATE) { listBack() }
        val top = 170f * u
        val rowH = 120f * u
        val maxScroll = max(0f, listItems.size * rowH - (h - top - 20f * u))
        listScroll = listScroll.coerceIn(0f, maxScroll)
        c.save()
        c.clipRect(0f, top, w, h)
        for (i in listItems.indices) {
            val y = top + i * rowH - listScroll
            if (y > h || y + rowH < top) continue
            fill.color = if (i == listHi) GREEN else if (i % 2 == 0) 0xFF1B2A38.toInt() else 0xFF22344A.toInt()
            c.drawRect(60f * u, y, w - 60f * u, y + rowH - 8f * u, fill)
            txt(c, listItems[i], 90f * u, y + rowH * 0.45f, 44f * u, WHITE)
            if (i < listSub.size) txt(c, listSub[i], w - 90f * u, y + rowH * 0.45f, 36f * u, GRAY, Paint.Align.RIGHT)
        }
        c.restore()
    }

    private fun drawHub(c: Canvas) {
        val cr = career ?: return
        c.drawColor(BG)
        txt(c, cr.myTeam() + "  •  " + cr.league().name, w / 2, 70f * u, 56f * u, WHITE, Paint.Align.CENTER)
        val total = cr.totalRounds()
        txt(c, "Temporada ${cr.season}  •  Rodada ${min(cr.round + 1, total)}/$total", w / 2, 135f * u, 38f * u, GRAY, Paint.Align.CENTER)

        fill.color = 0xFF1B2A38.toInt()
        c.drawRoundRect(60f * u, 190f * u, w / 2 - 20f * u, h - 230f * u, 24f * u, 24f * u, fill)
        c.drawRoundRect(w / 2 + 20f * u, 190f * u, w - 60f * u, h - 230f * u, 24f * u, 24f * u, fill)

        var y = 240f * u
        val lx = 100f * u
        val step = 62f * u
        txt(c, cr.name, lx, y, 54f * u, YELLOW); y += step + 10f * u
        txt(c, Data.posNames[cr.pos] + "  •  ${cr.age} anos  •  OVR ${cr.ovr()}", lx, y, 38f * u, WHITE); y += step
        val names = listOf("Chute", "Passe", "Drible", "Velocidade", "Defesa")
        for (i in 0..4) {
            txt(c, names[i], lx, y, 34f * u, GRAY)
            fill.color = 0xFF37474F.toInt()
            c.drawRect(lx + 260f * u, y - 14f * u, lx + 260f * u + 400f * u, y + 14f * u, fill)
            fill.color = GREEN
            c.drawRect(lx + 260f * u, y - 14f * u, lx + 260f * u + 400f * u * cr.attr(i) / 99f, y + 14f * u, fill)
            txt(c, cr.attr(i).toString(), lx + 690f * u, y, 34f * u, WHITE)
            y += 50f * u
        }
        y += 10f * u
        txt(c, "Temporada: ${cr.sGoals} gols, ${cr.sAssists} assist. em ${cr.sMatches} jogos", lx, y, 32f * u, WHITE); y += 48f * u
        txt(c, "Carreira: ${cr.goals} gols, ${cr.assists} assist. em ${cr.matches} jogos", lx, y, 32f * u, WHITE)

        val rx = w / 2 + 60f * u
        y = 240f * u
        val order = cr.sorted()
        txt(c, "Posição na tabela: ${order.indexOf(cr.teamIdx) + 1}º  (${cr.table[cr.teamIdx][0]} pts)", rx, y, 38f * u, WHITE)
        y += 80f * u
        if (cr.seasonOver()) {
            txt(c, "Temporada encerrada!", rx, y, 44f * u, YELLOW)
        } else {
            val f = cr.myFixture()
            if (f != null) {
                val home = f[0] == cr.teamIdx
                val opp = if (home) f[1] else f[0]
                txt(c, "Próximo jogo:", rx, y, 36f * u, GRAY); y += 60f * u
                txt(c, (if (home) "Em casa vs " else "Fora vs ") + cr.teamName(opp), rx, y, 42f * u, WHITE); y += 60f * u
                txt(c, "Força do rival: ${cr.strength(cr.leagueIdx, opp)}  •  a sua: ${cr.myStrength()}", rx, y, 32f * u, GRAY)
            } else {
                txt(c, "Rodada de folga", rx, y, 42f * u, WHITE)
            }
        }
        y += 90f * u
        txt(c, "Pontos de treino: ${cr.sp}", rx, y, 40f * u, YELLOW)

        val bw = (w - 120f * u - 4f * 20f * u) / 5f
        val t = h - 200f * u
        val b = h - 60f * u
        var x = 60f * u
        if (cr.seasonOver()) {
            btn(c, "FIM DA TEMPORADA", x, t, x + bw * 2 + 20f * u, b, RED) { openSeasonEnd() }
            x += bw * 2 + 40f * u
            btn(c, "TABELA", x, t, x + bw, b, BLUE) { openTable() }
            x += bw + 20f * u
            btn(c, "TREINAR", x, t, x + bw, b, GREEN) { screen = S_TRAIN }
        } else {
            btn(c, "JOGAR", x, t, x + bw, b, GREEN) { startMatch() }
            x += bw + 20f * u
            btn(c, "SIMULAR", x, t, x + bw, b, 0xFFEF6C00.toInt()) { simulateRound() }
            x += bw + 20f * u
            btn(c, "TABELA", x, t, x + bw, b, BLUE) { openTable() }
            x += bw + 20f * u
            btn(c, "TREINAR", x, t, x + bw, b, 0xFF6A1B9A.toInt()) { screen = S_TRAIN }
        }
        btn(c, "MENU", w - 60f * u - bw, t, w - 60f * u, b, SLATE) { save(); screen = S_MENU }
    }

    private fun drawResult(c: Canvas) {
        val r = lastRes ?: return
        val cr = career ?: return
        c.drawColor(BG)
        txt(c, "FIM DE JOGO", w / 2, 130f * u, 80f * u, YELLOW, Paint.Align.CENTER)
        val mine = cr.myTeam()
        val score = if (r.home) "$mine ${r.gf} x ${r.ga} ${r.opp}" else "${r.opp} ${r.ga} x ${r.gf} $mine"
        txt(c, score, w / 2, 260f * u, 60f * u, WHITE, Paint.Align.CENTER)
        txt(c, "Nota: ${r.rating}", w / 2, 380f * u, 70f * u, YELLOW, Paint.Align.CENTER)
        txt(c, "Gols: ${r.goals}   Assistências: ${r.assists}", w / 2, 480f * u, 48f * u, WHITE, Paint.Align.CENTER)
        txt(c, "+${r.sp} pontos de treino", w / 2, 560f * u, 44f * u, GRAY, Paint.Align.CENTER)
        btn(c, "CONTINUAR", w / 2 - 300f * u, 700f * u, w / 2 + 300f * u, 830f * u, GREEN) { screen = S_HUB }
    }

    private fun drawTrain(c: Canvas) {
        val cr = career ?: return
        c.drawColor(BG)
        txt(c, "TREINO  •  pontos: ${cr.sp}", w / 2, 100f * u, 64f * u, YELLOW, Paint.Align.CENTER)
        val names = listOf("Chute", "Passe", "Drible", "Velocidade", "Defesa")
        for (i in 0..4) {
            val y = (220f + i * 130f) * u
            txt(c, names[i], 200f * u, y + 40f * u, 48f * u, WHITE)
            txt(c, cr.attr(i).toString(), w / 2, y + 40f * u, 52f * u, YELLOW, Paint.Align.CENTER)
            btn(c, "+1", w - 460f * u, y, w - 200f * u, y + 90f * u, if (cr.sp > 0) GREEN else SLATE) {
                cr.addAttr(i)
            }
        }
        btn(c, "VOLTAR", 30f * u, 30f * u, 300f * u, 120f * u, SLATE) { save(); screen = S_HUB }
    }

    // ------------------------------------------------------------- partida

    private fun drawMatchScreen(c: Canvas) {
        val m = match ?: return
        drawMatch(c, m)
        drawHud(c, m)
        if (m.state == 4) {
            fill.color = 0xB0000000.toInt()
            c.drawRect(0f, 0f, w, h, fill)
            txt(c, "FIM DE JOGO", w / 2, 300f * u, 110f * u, YELLOW, Paint.Align.CENTER)
            txt(c, "${m.myName} ${m.score0} x ${m.score1} ${m.oppName}", w / 2, 450f * u, 64f * u, WHITE, Paint.Align.CENTER)
            btn(c, "CONTINUAR", w / 2 - 300f * u, 600f * u, w / 2 + 300f * u, 730f * u, GREEN) { finishMatch() }
        } else if (paused) {
            fill.color = 0xB0000000.toInt()
            c.drawRect(0f, 0f, w, h, fill)
            txt(c, "PAUSADO", w / 2, 250f * u, 100f * u, WHITE, Paint.Align.CENTER)
            btn(c, "CONTINUAR", w / 2 - 300f * u, 380f * u, w / 2 + 300f * u, 500f * u, GREEN) { paused = false }
            btn(c, "ABANDONAR PARTIDA", w / 2 - 300f * u, 540f * u, w / 2 + 300f * u, 660f * u, RED) {
                paused = false; match = null; screen = S_HUB
            }
        }
    }

    private fun drawMatch(c: Canvas, m: Match) {
        c.drawColor(0xFF1B5E20.toInt())
        val zoom = h / 640f
        val tx = m.me.x * 0.7f + m.bx * 0.3f
        val ty = m.me.y * 0.7f + m.by * 0.3f
        camX += (tx - camX) * 0.1f
        camY += (ty - camY) * 0.1f
        c.save()
        c.scale(zoom, zoom)
        c.translate(w / (2f * zoom) - camX, h / (2f * zoom) - camY)

        val W = Match.W
        val H = Match.H
        val sw = W / 14f
        for (i in 0 until 14) {
            fill.color = if (i % 2 == 0) 0xFF2E7D32.toInt() else 0xFF388E3C.toInt()
            c.drawRect(i * sw, 0f, (i + 1) * sw, H, fill)
        }
        stroke.color = WHITE
        stroke.strokeWidth = 4f
        c.drawRect(0f, 0f, W, H, stroke)
        c.drawLine(W / 2, 0f, W / 2, H, stroke)
        c.drawCircle(W / 2, H / 2, 110f, stroke)
        fill.color = WHITE
        c.drawCircle(W / 2, H / 2, 5f, fill)
        c.drawRect(0f, H / 2 - 260f, 220f, H / 2 + 260f, stroke)
        c.drawRect(W - 220f, H / 2 - 260f, W, H / 2 + 260f, stroke)
        c.drawRect(0f, H / 2 - 130f, 80f, H / 2 + 130f, stroke)
        c.drawRect(W - 80f, H / 2 - 130f, W, H / 2 + 130f, stroke)
        fill.color = 0x55FFFFFF
        c.drawRect(-40f, H / 2 - Match.GH, 0f, H / 2 + Match.GH, fill)
        c.drawRect(W, H / 2 - Match.GH, W + 40f, H / 2 + Match.GH, fill)
        c.drawRect(-40f, H / 2 - Match.GH, 0f, H / 2 + Match.GH, stroke)
        c.drawRect(W, H / 2 - Match.GH, W + 40f, H / 2 + Match.GH, stroke)

        for (p in m.players) {
            val col = if (p.team == 0) (if (p.role == 0) 0xFFFFEB3B else 0xFF1E88E5)
            else (if (p.role == 0) 0xFF8BC34A else 0xFFE53935)
            fill.color = col.toInt()
            c.drawCircle(p.x, p.y, 14f, fill)
            stroke.color = BLACK
            stroke.strokeWidth = 2.5f
            c.drawCircle(p.x, p.y, 14f, stroke)
            fill.color = WHITE
            c.drawCircle(p.x + cos(p.face) * 9f, p.y + sin(p.face) * 9f, 4f, fill)
            if (p.stun > 0.3f && !p.human) {
                txt(c, "x_x", p.x, p.y - 26f, 18f, WHITE, Paint.Align.CENTER)
            }
            if (p.human) {
                stroke.color = YELLOW
                stroke.strokeWidth = 4f
                c.drawCircle(p.x, p.y, 21f, stroke)
                txt(c, career?.name ?: "", p.x, p.y - 34f, 22f, YELLOW, Paint.Align.CENTER)
                if (m.callT > 0f) txt(c, "PEDINDO!", p.x, p.y - 58f, 22f, WHITE, Paint.Align.CENTER)
            }
        }
        fill.color = 0x55000000
        c.drawCircle(m.bx + 2f, m.by + 3f, 7f, fill)
        fill.color = WHITE
        c.drawCircle(m.bx, m.by, 7f, fill)
        stroke.color = BLACK
        stroke.strokeWidth = 2f
        c.drawCircle(m.bx, m.by, 7f, stroke)
        c.restore()
    }

    private fun drawHud(c: Canvas, m: Match) {
        fill.color = 0xB0000000.toInt()
        c.drawRoundRect(w / 2 - 520f * u, 14f * u, w / 2 + 520f * u, 110f * u, 20f * u, 20f * u, fill)
        txt(c, m.myName, w / 2 - 100f * u, 62f * u, 36f * u, WHITE, Paint.Align.RIGHT)
        txt(c, "${m.score0} x ${m.score1}", w / 2, 62f * u, 58f * u, YELLOW, Paint.Align.CENTER)
        txt(c, m.oppName, w / 2 + 100f * u, 62f * u, 36f * u, WHITE)
        txt(c, "${min(90, m.time.toInt())}'", w / 2 + 470f * u, 62f * u, 34f * u, WHITE, Paint.Align.CENTER)

        // barras
        fill.color = 0x88000000.toInt()
        c.drawRect(20f * u, 20f * u, 340f * u, 76f * u, fill)
        fill.color = 0xFF4CAF50.toInt()
        c.drawRect(24f * u, 24f * u, 24f * u + 312f * u * m.stam / 100f, 44f * u, fill)
        fill.color = if (m.superM >= 100f) 0xFFFF5252.toInt() else 0xFFFFB300.toInt()
        c.drawRect(24f * u, 52f * u, 24f * u + 312f * u * m.superM / 100f, 72f * u, fill)
        txt(c, "FÔLEGO / SUPER", 20f * u, 96f * u, 24f * u, WHITE)

        // pausa
        fill.color = 0x88000000.toInt()
        c.drawCircle(w - 80f * u, 80f * u, 55f * u, fill)
        txt(c, "II", w - 80f * u, 80f * u, 40f * u, WHITE, Paint.Align.CENTER)

        if (m.state != 0 && m.state != 4) {
            txt(c, m.msg, w / 2 + 3f * u, h / 2 - 60f * u + 3f * u, 120f * u, BLACK, Paint.Align.CENTER)
            txt(c, m.msg, w / 2, h / 2 - 60f * u, 120f * u, WHITE, Paint.Align.CENTER)
        }
        if (m.state == 0 || m.state == 2) {
            // joystick
            val jcx = if (joyId == -1) 230f * u else joyCx
            val jcy = if (joyId == -1) h - 230f * u else joyCy
            fill.color = 0x40FFFFFF
            c.drawCircle(jcx, jcy, 140f * u, fill)
            fill.color = 0x90FFFFFF.toInt()
            c.drawCircle(jcx + m.jx * 130f * u, jcy + m.jy * 130f * u, 60f * u, fill)

            val hasBall = m.owner === m.me
            for (i in 0..6) {
                var label = ctlName[i]
                if (i == 0 && !hasBall) label = "DESARME"
                val pressed = i == 6 && m.sprintHeld
                fill.color = (if (pressed) 0xFFFFFFFF.toInt() else ctlCol[i]) and 0x00FFFFFF or (0xB0 shl 24)
                c.drawCircle(cx(i), cy(i), cr(i), fill)
                if (i == 3) {
                    fill.color = 0xFFFFEB3B.toInt()
                    val rc = RectF(cx(i) - cr(i), cy(i) - cr(i), cx(i) + cr(i), cy(i) + cr(i))
                    c.drawArc(rc, -90f, 360f * m.superM / 100f, false, stroke.apply { color = 0xFFFFEB3B.toInt(); strokeWidth = 8f * u })
                }
                txt(c, label, cx(i), cy(i), (if (label.length > 6) 24f else 30f) * u, WHITE, Paint.Align.CENTER)
            }
        }
    }
}
