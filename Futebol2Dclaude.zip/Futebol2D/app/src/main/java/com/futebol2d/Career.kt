package com.futebol2d

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.max
import kotlin.random.Random

class Career {
    class MatchRes(
        val gf: Int, val ga: Int, val goals: Int, val assists: Int,
        val rating: Float, val sp: Int, val opp: String, val home: Boolean
    )

    var name = "Jogador"
    var pos = 2
    var age = 17
    var shoot = 55
    var pass = 55
    var drib = 55
    var spd = 60
    var def = 35
    var leagueIdx = 0
    var teamIdx = 0
    var season = 1
    var round = 0
    var goals = 0
    var assists = 0
    var matches = 0
    var sGoals = 0
    var sAssists = 0
    var sMatches = 0
    var sp = 3
    var table: Array<IntArray> = emptyArray()
    val offers = ArrayList<IntArray>()

    fun league() = Data.leagues[leagueIdx]
    fun n() = league().teams.size
    fun teamName(i: Int) = league().teams[i]
    fun myTeam() = teamName(teamIdx)
    fun strength(l: Int, t: Int): Int {
        val lg = Data.leagues[l]
        return lg.base - t * 14 / lg.teams.size
    }
    fun myStrength() = strength(leagueIdx, teamIdx)

    fun ovr(): Int {
        val v = when (pos) {
            2 -> shoot * 0.35 + drib * 0.25 + spd * 0.2 + pass * 0.12 + def * 0.08
            1 -> pass * 0.3 + drib * 0.25 + shoot * 0.15 + spd * 0.15 + def * 0.15
            else -> def * 0.4 + spd * 0.2 + pass * 0.2 + drib * 0.1 + shoot * 0.1
        }
        return v.toInt()
    }

    fun attr(i: Int): Int = when (i) { 0 -> shoot; 1 -> pass; 2 -> drib; 3 -> spd; else -> def }

    fun addAttr(i: Int) {
        if (sp <= 0 || attr(i) >= 99) return
        sp--
        when (i) { 0 -> shoot++; 1 -> pass++; 2 -> drib++; 3 -> spd++; else -> def++ }
    }

    fun start(nm: String, p: Int, l: Int, t: Int) {
        name = nm; pos = p; age = 17; leagueIdx = l; teamIdx = t
        when (p) {
            2 -> { shoot = 60; pass = 50; drib = 58; spd = 62; def = 30 }
            1 -> { shoot = 52; pass = 62; drib = 58; spd = 56; def = 45 }
            else -> { shoot = 38; pass = 52; drib = 44; spd = 55; def = 62 }
        }
        season = 1; goals = 0; assists = 0; matches = 0; sp = 3
        resetSeason()
    }

    fun resetSeason() {
        table = Array(n()) { IntArray(7) }
        round = 0; sGoals = 0; sAssists = 0; sMatches = 0
    }

    fun fixtures(): List<List<IntArray>> = makeFixtures(n())
    fun totalRounds(): Int = fixtures().size
    fun seasonOver(): Boolean = round >= totalRounds()

    fun myFixture(): IntArray? {
        if (seasonOver()) return null
        return fixtures()[round].firstOrNull { it[0] == teamIdx || it[1] == teamIdx }
    }

    fun sorted(): List<Int> = (0 until n()).sortedWith(
        compareByDescending<Int> { table[it][0] }
            .thenByDescending { table[it][5] - table[it][6] }
            .thenByDescending { table[it][5] }
    )

    private fun applyResult(h: Int, a: Int, gh: Int, ga: Int) {
        val th = table[h]; val ta = table[a]
        th[1]++; ta[1]++
        th[5] += gh; th[6] += ga; ta[5] += ga; ta[6] += gh
        if (gh > ga) { th[0] += 3; th[2]++; ta[4]++ }
        else if (gh < ga) { ta[0] += 3; ta[2]++; th[4]++ }
        else { th[0]++; ta[0]++; th[3]++; ta[3]++ }
    }

    /** Joga a rodada: seu resultado (myGF/myGA) + simula os demais jogos. */
    fun finishRound(myGF: Int, myGA: Int) {
        for (m in fixtures()[round]) {
            val h = m[0]; val a = m[1]
            if (h == teamIdx) applyResult(h, a, myGF, myGA)
            else if (a == teamIdx) applyResult(h, a, myGA, myGF)
            else {
                val s = simScore(strength(leagueIdx, h), strength(leagueIdx, a))
                applyResult(h, a, s[0], s[1])
            }
        }
        round++
    }

    fun applyPlayerStats(g: Int, a: Int, rating: Float): Int {
        goals += g; assists += a; matches++
        sGoals += g; sAssists += a; sMatches++
        val gain = 1 + (if (rating >= 7f) 1 else 0) + (if (rating >= 8.5f) 1 else 0)
        sp += gain
        return gain
    }

    fun generateOffers() {
        offers.clear()
        val target = ovr() + Random.nextInt(-3, 9)
        val cands = ArrayList<IntArray>()
        for (l in Data.leagues.indices) for (t in Data.leagues[l].teams.indices) {
            if (l == leagueIdx && t == teamIdx) continue
            if (abs(strength(l, t) - target) <= 3) cands.add(intArrayOf(l, t))
        }
        cands.shuffle()
        for (i in 0 until minOf(4, cands.size)) offers.add(cands[i])
    }

    private fun bump(i: Int) {
        when (i) {
            0 -> shoot = minOf(99, shoot + 1)
            1 -> pass = minOf(99, pass + 1)
            2 -> drib = minOf(99, drib + 1)
            3 -> spd = minOf(99, spd + 1)
            else -> def = minOf(99, def + 1)
        }
    }

    fun newSeason(offer: Int) {
        if (offer in offers.indices) {
            leagueIdx = offers[offer][0]
            teamIdx = offers[offer][1]
        }
        age++
        season++
        val up = if (age <= 24) 3 else if (age <= 30) 1 else 0
        repeat(up) { bump(Random.nextInt(5)) }
        if (age >= 31) spd = max(30, spd - 1)
        sp += 3
        offers.clear()
        resetSeason()
    }

    fun save(ctx: Context) {
        val o = JSONObject()
        o.put("name", name); o.put("pos", pos); o.put("age", age)
        o.put("shoot", shoot); o.put("pass", pass); o.put("drib", drib); o.put("spd", spd); o.put("def", def)
        o.put("league", leagueIdx); o.put("team", teamIdx)
        o.put("season", season); o.put("round", round)
        o.put("goals", goals); o.put("assists", assists); o.put("matches", matches)
        o.put("sGoals", sGoals); o.put("sAssists", sAssists); o.put("sMatches", sMatches)
        o.put("sp", sp)
        val t = JSONArray()
        for (r in table) {
            val a = JSONArray()
            for (v in r) a.put(v)
            t.put(a)
        }
        o.put("table", t)
        ctx.getSharedPreferences("f2d", 0).edit().putString("career", o.toString()).apply()
    }

    companion object {
        fun load(ctx: Context): Career? {
            val s = ctx.getSharedPreferences("f2d", 0).getString("career", null) ?: return null
            return try {
                val o = JSONObject(s)
                val c = Career()
                c.name = o.getString("name"); c.pos = o.getInt("pos"); c.age = o.getInt("age")
                c.shoot = o.getInt("shoot"); c.pass = o.getInt("pass"); c.drib = o.getInt("drib")
                c.spd = o.getInt("spd"); c.def = o.getInt("def")
                c.leagueIdx = o.getInt("league"); c.teamIdx = o.getInt("team")
                c.season = o.getInt("season"); c.round = o.getInt("round")
                c.goals = o.getInt("goals"); c.assists = o.getInt("assists"); c.matches = o.getInt("matches")
                c.sGoals = o.getInt("sGoals"); c.sAssists = o.getInt("sAssists"); c.sMatches = o.getInt("sMatches")
                c.sp = o.getInt("sp")
                val t = o.getJSONArray("table")
                c.table = Array(t.length()) { i ->
                    val r = t.getJSONArray(i)
                    IntArray(7) { j -> r.getInt(j) }
                }
                if (c.leagueIdx >= Data.leagues.size || c.teamIdx >= c.n() || c.table.size != c.n()) null else c
            } catch (e: Exception) {
                null
            }
        }

        fun makeFixtures(n: Int): List<List<IntArray>> {
            val arr = ArrayList<Int>()
            for (i in 0 until n) arr.add(i)
            if (n % 2 == 1) arr.add(-1)
            val m = arr.size
            val rounds = ArrayList<List<IntArray>>()
            for (r in 0 until m - 1) {
                val list = ArrayList<IntArray>()
                for (i in 0 until m / 2) {
                    val a = arr[i]; val b = arr[m - 1 - i]
                    if (a >= 0 && b >= 0) list.add(if (r % 2 == 0) intArrayOf(a, b) else intArrayOf(b, a))
                }
                rounds.add(list)
                val last = arr.removeAt(m - 1)
                arr.add(1, last)
            }
            val second = rounds.map { rd -> rd.map { intArrayOf(it[1], it[0]) } }
            return rounds + second
        }

        private fun poisson(l: Double): Int {
            val lim = Math.exp(-l)
            var k = 0
            var p = 1.0
            do {
                k++
                p *= Random.nextDouble()
            } while (p > lim)
            return k - 1
        }

        /** [golsMandante, golsVisitante] */
        fun simScore(sh: Int, sa: Int): IntArray {
            val d = (sh - sa) / 25.0
            return intArrayOf(poisson(max(0.3, 1.45 + d)), poisson(max(0.3, 1.15 - d)))
        }

        fun calcRating(g: Int, a: Int, ok: Int, bad: Int, dr: Int, loss: Int, gf: Int, ga: Int): Float {
            var r = 6.0f + g * 1.0f + a * 0.7f + ok * 0.05f - bad * 0.06f + dr * 0.12f - loss * 0.12f
            r += if (gf > ga) 0.4f else if (gf < ga) -0.3f else 0f
            return Math.round(r.coerceIn(3f, 10f) * 10) / 10f
        }
    }
}
