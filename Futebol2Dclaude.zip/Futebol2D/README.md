# Futebol 2D Carreira (Android 16 / API 36)

Jogo de futebol 2D em Kotlin puro (Canvas), sem dependências externas.

## Como gerar o APK (GitHub)
1. Crie um repositório e envie todo o conteúdo desta pasta (inclusive `.github/`).
2. Abra a aba **Actions → Build Android APK → Run workflow** (ou faça um push na `main`).
3. Ao terminar, baixe o artefato **Futebol2D-debug-apk** (contém `app-debug.apk`).
4. Para publicar em Releases, crie uma tag, por exemplo `v1.0`.

## Controles
- Joystick flutuante: toque na metade esquerda da tela.
- PASSE (com a bola) / DESARME (sem a bola)
- CHUTE normal, COLOC. (chute colocado no canto, direção pelo joystick), SUPER (barra amarela cheia)
- PEDIR: pede o passe ao companheiro com a bola
- DRIBLE: finta com arrancada, pode derrubar o marcador
- CORRER: segure para correr (gasta fôlego)

## Carreira
Crie o jogador, escolha liga e clube, jogue ou simule rodadas, treine atributos
com os pontos ganhos e escolha propostas de outros clubes no fim da temporada.
Edite `Data.kt` para adicionar mais ligas e clubes.
